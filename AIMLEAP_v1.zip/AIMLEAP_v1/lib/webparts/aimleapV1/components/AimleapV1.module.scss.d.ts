declare const styles: {
    aimleapV1: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=AimleapV1.module.scss.d.ts.map