import * as React from 'react';
import type { IAimleapV1Props } from './IAimleapV1Props';
export default class AimleapV1 extends React.Component<IAimleapV1Props, any> {
    constructor(props: any);
    private bind_data;
    componentWillMount(): void;
    handlefilter_new(event: any): void;
    render(): React.ReactElement<IAimleapV1Props>;
}
//# sourceMappingURL=AimleapV1.d.ts.map