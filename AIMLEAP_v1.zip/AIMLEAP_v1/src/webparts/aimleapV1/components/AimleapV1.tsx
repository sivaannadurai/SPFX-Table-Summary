import * as React from 'react';
import styles from './AimleapV1.module.scss';
import type { IAimleapV1Props } from './IAimleapV1Props';
//import { escape } from '@microsoft/sp-lodash-subset';
import axios from 'axios';
import DataTable from 'react-data-table-component';
//import { format } from "date-fns";
export default class AimleapV1 extends React.Component<IAimleapV1Props, any> {

  constructor(props:any) {
    super(props);
    this.handlefilter_new = this.handlefilter_new.bind(this);
  } 
  
  private  bind_data() 
  {
    debugger;
    axios.get(this.props.sharepointurl + "_api/Web/lists/getbytitle('" + this.props.listname + "')/items?$Select=ID,Title,Created,Modified&$top="+this.props.noofitems+"&$orderby=ID%20asc")
      .then(response => {
        if (response !== null && response !== undefined && response.data !== null && response.data !== undefined) {
          let results = response.data["value"];
          results.map((item:any) => {
          });          
         let  itemsArrV2 = [];
          for (var i = 0; i < results.length; i++) {
            var news = {
              ID: results[i]['ID'] !== null || results[i]['ID'] !== undefined ? results[i]['ID'] : "Coming Soong",
              Title:results[i]["Title"] !== null || results[i]["Title"] !== undefined ? results[i]["Title"] : "Coming Soon",
              Created: results[i]["Created"] !== null || results[i]["Created"] !== undefined ? results[i]["Created"]: "Coming Soon",
              Modified: results[i]["Modified"] !== null || results[i]["Modified"] !== undefined ? results[i]["Modified"]: "Coming Soon"
  
            };
            itemsArrV2.push(news);
            
          }

          
          
          this.setState({ CompanyNewsNw: itemsArrV2 },()=>console.log(this.state.itemsArrV2));
         
          return itemsArrV2;
        }
  
      }).catch((error) => {
        console.log(error);
     
       
      });

     
  }

  
  public componentWillMount() {
   
    debugger;
    let dID=1;
    console.log(dID);
   this.setState({datumID: dID},()=>console.log(this.state.datumID)); 
   
    this.bind_data();
    
  }

  handlefilter_new(event:any)
    {
      debugger;
      

      if(this.state.CompanyNewsNw.length==0)
      {
        this.bind_data();
      }
      
      const newdata=this.state.CompanyNewsNw.filter((row: any) =>
      {
        return row.Title.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase())
      }
      )
      

    debugger;

    this.setState({ CompanyNewsNw: newdata },()=>console.log(this.state.CompanyNewsNw));
debugger;
    }
  public render(): React.ReactElement<IAimleapV1Props> {


    const {
     
     
      hasTeamsContext,
      
    } = this.props;
    
  let columns =[

    {

      name:"Title",
      selector :(row:any)=>row.Title,
      sortable: true
    },
    {
      name:"Created",
      selector :(row:any)=>row.Created,
      sortable: true
    },
    {
      name:"Modified",
      selector :(row:any)=>row.Modified,
      sortable: true
    }
  ];


console.log(this.state.datumID);
console.log(this.state.CompanyNewsNw);
 
    return (
      <section className={`${styles.aimleapV1} ${hasTeamsContext ? styles.teams : ''}`}>
        <div className={styles.welcome}>          
        </div>
        <div>
          <input type='text' onChange={this.handlefilter_new} ></input>
          </div> 
        <div>        
<DataTable
columns={columns} data=  {this.state.CompanyNewsNw} pagination
fixedHeader
></DataTable>
          
        </div>
      </section>
    );
  }
}
