export interface IAimleapV1Props {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  listname: string;
  sharepointurl:string;
  noofitems:number;
}
