/* tslint:disable */
require("./AimleapV1.module.css");
const styles = {
  aimleapV1: 'aimleapV1_d538e76c',
  teams: 'teams_d538e76c',
  welcome: 'welcome_d538e76c',
  welcomeImage: 'welcomeImage_d538e76c',
  links: 'links_d538e76c'
};

export default styles;
/* tslint:enable */